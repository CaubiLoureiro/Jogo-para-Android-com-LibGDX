<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="water" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="water.png" width="512" height="512"/>
 <wangsets>
  <wangset name="river" type="mixed" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="51" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="52" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="53" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="67" wangid="0,1,1,1,0,0,0,0"/>
   <wangtile tileid="68" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="69" wangid="0,0,0,0,0,1,1,1"/>
   <wangtile tileid="83" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="84" wangid="1,1,0,0,0,0,0,1"/>
   <wangtile tileid="85" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="86" wangid="1,1,0,0,0,1,1,1"/>
   <wangtile tileid="87" wangid="1,1,1,1,0,0,0,1"/>
   <wangtile tileid="102" wangid="0,0,0,1,1,1,1,1"/>
   <wangtile tileid="103" wangid="0,1,1,1,1,1,0,0"/>
  </wangset>
 </wangsets>
</tileset>
