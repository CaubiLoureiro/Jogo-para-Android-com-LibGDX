<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="TUTterrain" tilewidth="32" tileheight="32" tilecount="1024" columns="32" objectalignment="center">
 <image source="TUTterrain.png" width="1024" height="1024"/>
 <wangsets>
  <wangset name="river" type="mixed" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="566" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="567" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="598" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="599" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="629" wangid="1,1,0,0,0,1,1,1"/>
   <wangtile tileid="630" wangid="1,1,0,0,0,0,0,1"/>
   <wangtile tileid="631" wangid="1,1,1,1,0,0,0,1"/>
   <wangtile tileid="661" wangid="0,0,0,0,0,1,1,1"/>
   <wangtile tileid="663" wangid="0,1,1,1,0,0,0,0"/>
   <wangtile tileid="693" wangid="0,0,0,1,1,1,1,1"/>
   <wangtile tileid="694" wangid="0,0,0,1,1,1,0,0"/>
   <wangtile tileid="695" wangid="0,1,1,1,1,1,0,0"/>
  </wangset>
 </wangsets>
</tileset>
